import Exam from "../models/Exam.js";

/* ================= GET ALL EXAMS ================= */
export const getAllExams = async (req, res) => {
  try {
    const {
      department,
      semester,
      course,
      group,
      status,
      examType,
      fromDate,
      toDate,
      search,
    } = req.query;

    const query = { isDeleted: { $ne: true } };

    if (department) query.department = department;
    if (semester) query.semester = Number(semester);
    if (course) query.course = course;
    if (group) query.group = group;
    if (status) query.status = String(status).toUpperCase();
    if (examType) query.examType = String(examType).toUpperCase();

    if (fromDate || toDate) {
      query.examDate = {};
      if (fromDate) query.examDate.$gte = new Date(fromDate);
      if (toDate) query.examDate.$lte = new Date(toDate);
    }

    if (search) {
      const term = String(search).trim();
      query.$or = [
        { examName: { $regex: term, $options: "i" } },
        { subjectCode: { $regex: term, $options: "i" } },
        { subjectName: { $regex: term, $options: "i" } },
      ];
    }

    const exams = await Exam.find(query)
      .sort({ examDate: 1, startTime: 1 })
      .populate("department", "name")
      .populate("course", "code courseName semester")
      .populate("group", "name")
      .populate({ path: "invigilators", select: "employeeId", populate: { path: "user", select: "name" } });

    return res.json({
      message: "Exams fetched successfully",
      count: exams.length,
      exams,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/* ================= GET EXAM BY ID ================= */
export const getExamById = async (req, res) => {
  try {
    const { id } = req.params;

    const exam = await Exam.findOne({ _id: id, isDeleted: { $ne: true } })
      .populate("department", "name")
      .populate("course", "code courseName semester")
      .populate("group", "name")
      .populate({ path: "invigilators", select: "employeeId", populate: { path: "user", select: "name" } });

    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    return res.json({ message: "Exam fetched successfully", exam });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/* ================= ADD EXAM ================= */
export const addExam = async (req, res) => {
  try {
    const payload = req.body || {};

    const exam = await Exam.create(payload);
    const created = await Exam.findById(exam._id)
      .populate("department", "name")
      .populate("course", "code courseName semester")
      .populate("group", "name")
      .populate({ path: "invigilators", select: "employeeId", populate: { path: "user", select: "name" } });

    return res.status(201).json({
      message: "Exam created successfully",
      exam: created,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/* ================= UPDATE EXAM ================= */
export const updateExam = async (req, res) => {
  try {
    const { id } = req.params;

    const exam = await Exam.findOneAndUpdate(
      { _id: id, isDeleted: { $ne: true } },
      req.body,
      { new: true, runValidators: true }
    )
      .populate("department", "name")
      .populate("course", "code courseName semester")
      .populate("group", "name")
      .populate({ path: "invigilators", select: "employeeId", populate: { path: "user", select: "name" } });

    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    return res.json({ message: "Exam updated successfully", exam });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/* ================= DELETE EXAM ================= */
export const deleteExam = async (req, res) => {
  try {
    const { id } = req.params;

    const exam = await Exam.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true }
    );

    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    return res.json({ message: "Exam deleted successfully" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/* ================= HARD DELETE EXAM ================= */
export const hardDeleteExam = async (req, res) => {
  try {
    const { id } = req.params;

    const exam = await Exam.findByIdAndDelete(id);
    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    return res.json({ message: "Exam permanently deleted" });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};
