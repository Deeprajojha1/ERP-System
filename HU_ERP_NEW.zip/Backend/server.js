import express from "express";
import dotenv from "dotenv";
import connectDB from "./config/connectionDB.js";
import cors from "cors";
import cookieParser from "cookie-parser";
import userRoutes from "./Routes/userRoutes.js";
import adminRoutes from "./Routes/adminRoutes.js";
import facultyRoutes from "./Routes/facultyRoutes.js";
import studentRoutes from "./Routes/studentRoutes.js";
dotenv.config();

const app = express();
// CORS configuration
// NOTE: Origin is only scheme + host (+ optional port), no path.
const allowedOrigins = [
  "https://hu-erp-git-development-subeshs-projects.vercel.app", // Local development (Vite)
  "https://hu-erp1.vercel.app",
  "http://localhost:5173", // Production Vercel
  process.env.FRONTEND_URL, // Optional override via env on Render
].filter(Boolean);

console.log("[CORS] Allowed origins:", allowedOrigins);

app.use(
  cors({
    origin(origin, callback) {
      // Allow requests with no origin (e.g., curl, mobile apps)
      if (!origin) {
        console.log("[CORS] Request with no origin allowed");
        return callback(null, true);
      }

      console.log("[CORS] Incoming origin:", origin);

      if (!allowedOrigins.includes(origin)) {
        console.error("[CORS] Blocked origin:", origin, "Allowed:", allowedOrigins);
        const msg =
          "The CORS policy for this site does not allow access from the specified Origin.";
        return callback(new Error(msg), false);
      }

      console.log("[CORS] Origin allowed:", origin);
      return callback(null, true);
    },
    credentials: true,
  })
);
// Database connection
connectDB();
// Body parser
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());

// routes
app.use('/api/user/', userRoutes)
app.use('/api/admin/', adminRoutes)
app.use('/api/faculty/', facultyRoutes)
app.use('/api/student/', studentRoutes)
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

export default app;