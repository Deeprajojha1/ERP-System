import User from "../models/userModel.js";
import Student from "../models/Student.js";
import Enrollment from "../models/Enrollment.js";
import AttendanceSession from "../models/AttendanceSession.js";
import Course from "../models/Course.js";
import Group from "../models/Group.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import validator from "validator";

const { isEmail } = validator;

/* ================= STUDENT LOGIN ================= */

export const studentLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        message: "Email & Password required",
      });
    }

    if (!isEmail(email)) {
      return res.status(400).json({
        message: "Invalid email format",
      });
    }

    /* Find user */
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({
        message: "User not found",
      });
    }

    /* Check role */
    if (user.role !== "student") {
      return res.status(403).json({
        message: "Access denied. Not a student account.",
      });
    }

    /* Compare password */
    const isMatch = await bcrypt.compare(password, user.passwordHash);

    if (!isMatch) {
      return res.status(401).json({
        message: "Invalid credentials",
      });
    }

    /* Generate JWT */
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    /* Store cookie */
    res.cookie("token", token, {
      httpOnly: true,
      secure: false,
      sameSite: "strict",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    /* Fetch student details */
    const studentDetails = await Student.findOne({ user: user._id })
      .populate("department", "name code")
      .populate({
        path: "group",
        select: "name roomNo department courseIds",
        populate: {
          path: "courseIds",
          select: "code courseName department semester branch credit",
          populate: {
            path: "department",
            select: "name code"
          }
        }
      });

    if (!studentDetails) {
      return res.status(404).json({
        message: "Student profile not found",
      });
    }

    /* Fetch enrolled courses from group or enrollment collection */
    let enrolledCourses = [];
    
    // First, try to get courses from the group
    if (studentDetails.group && studentDetails.group.courseIds) {
      enrolledCourses = studentDetails.group.courseIds;
    }
    
    // If no courses from group, check Enrollment collection
    if (enrolledCourses.length === 0) {
      const enrollments = await Enrollment.find({ 
        student: studentDetails._id,
        status: "active"
      }).populate({
        path: "course",
        select: "code courseName department semester branch credit",
        populate: {
          path: "department",
          select: "name code"
        }
      });
      enrolledCourses = enrollments.map(enrollment => enrollment.course);
    }

    /* Fetch attendance data for all enrolled courses */
    const attendanceData = await Promise.all(
      enrolledCourses.map(async (course) => {
        const courseId = course._id;
        
        /* Get all attendance sessions for this student's group and course */
        const sessions = await AttendanceSession.find({
          group: studentDetails.group?._id,
          course: courseId,
        }).sort({ date: -1 });

        /* Calculate attendance stats */
        let presentCount = 0;
        let absentCount = 0;

        sessions.forEach((session) => {
          const studentRecord = session.records.find(
            (record) => record.student.toString() === studentDetails._id.toString()
          );

          if (studentRecord) {
            if (studentRecord.status === "present") {
              presentCount++;
            } else if (studentRecord.status === "absent") {
              absentCount++;
            }
          }
        });

        const totalSessions = presentCount + absentCount;
        const attendancePercentage = totalSessions > 0
          ? ((presentCount / totalSessions) * 100).toFixed(2)
          : 0;

        return {
          course: {
            _id: course._id,
            code: course.code,
            courseName: course.courseName,
          },
          totalSessions,
          presentCount,
          absentCount,
          attendancePercentage: parseFloat(attendancePercentage),
          recentSessions: sessions.slice(0, 5).map((session) => {
            const studentRecord = session.records.find(
              (record) => record.student.toString() === studentDetails._id.toString()
            );
            return {
              date: session.date,
              status: studentRecord ? studentRecord.status : "not-marked",
            };
          }),
        };
      })
    );

    /* Calculate overall attendance */
    const totalAllSessions = attendanceData.reduce((sum, data) => sum + data.totalSessions, 0);
    const totalPresentCount = attendanceData.reduce((sum, data) => sum + data.presentCount, 0);
    const overallAttendancePercentage = totalAllSessions > 0
      ? ((totalPresentCount / totalAllSessions) * 100).toFixed(2)
      : 0;

    /* Get today's schedule from group */
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const today = dayNames[new Date().getDay()];
    const todaySchedule = [];

    if (studentDetails.group) {
      const groupDetails = await Group.findById(studentDetails.group._id);
      const todayMap = groupDetails?.scheduleSlots?.get(today);

      if (todayMap) {
        for (const [lectureNumber, courseId] of todayMap.entries()) {
          const courseDoc = await Course.findById(courseId);
          if (courseDoc) {
            todaySchedule.push({
              lectureNumber: Number(lectureNumber),
              course: {
                _id: courseDoc._id,
                code: courseDoc.code,
                courseName: courseDoc.courseName,
              },
            });
          }
        }
      }

      todaySchedule.sort((a, b) => a.lectureNumber - b.lectureNumber);
    }

    res.json({
      message: "Student login successful",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        aadharNumber: user.aadharNumber,
        phoneNumber: user.phoneNumber,
        DOB: user.DOB,
        role: user.role,
        status: user.status,
      },
      studentDetails: {
        _id: studentDetails._id,
        enrollmentNumber: studentDetails.enrollmentNumber,
        department: studentDetails.department,
        program: studentDetails.program,
        semester: studentDetails.semester,
        academicYear: studentDetails.academicYear,
        fatherName: studentDetails.fatherName,
        fatherPhoneNumber: studentDetails.fatherPhoneNumber,
        collegeEmail: studentDetails.collegeEmail,
        group: studentDetails.group,
      },
      enrolledCourses,
      attendanceData,
      overallAttendance: {
        totalSessions: totalAllSessions,
        presentCount: totalPresentCount,
        absentCount: totalAllSessions - totalPresentCount,
        percentage: parseFloat(overallAttendancePercentage),
      },
      today,
      todaySchedule,
      token,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

/* ================= GET STUDENT PROFILE ================= */

export const getStudentProfile = async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    if (!user || user.role !== "student") {
      return res.status(403).json({
        message: "Access denied. Not a student account.",
      });
    }

    const studentDetails = await Student.findOne({ user: user._id })
      .populate("department", "name code")
      .populate({
        path: "group",
        select: "name roomNo department courseIds",
        populate: {
          path: "courseIds",
          select: "code courseName department semester branch credit",
          populate: {
            path: "department",
            select: "name code"
          }
        }
      });

    if (!studentDetails) {
      return res.status(404).json({
        message: "Student profile not found",
      });
    }

    /* Fetch enrolled courses from group or enrollment collection */
    let enrolledCourses = [];
    
    // First, try to get courses from the group
    if (studentDetails.group && studentDetails.group.courseIds) {
      enrolledCourses = studentDetails.group.courseIds;
    }
    
    // If no courses from group, check Enrollment collection
    if (enrolledCourses.length === 0) {
      const enrollments = await Enrollment.find({ 
        student: studentDetails._id,
        status: "active"
      }).populate({
        path: "course",
        select: "code courseName department semester branch credit",
        populate: {
          path: "department",
          select: "name code"
        }
      });
      enrolledCourses = enrollments.map(enrollment => enrollment.course);
    }

    /* Fetch attendance data for all enrolled courses */
    const attendanceData = await Promise.all(
      enrolledCourses.map(async (course) => {
        const courseId = course._id;
        
        const sessions = await AttendanceSession.find({
          group: studentDetails.group?._id,
          course: courseId,
        }).sort({ date: -1 });

        let presentCount = 0;
        let absentCount = 0;

        sessions.forEach((session) => {
          const studentRecord = session.records.find(
            (record) => record.student.toString() === studentDetails._id.toString()
          );

          if (studentRecord) {
            if (studentRecord.status === "present") {
              presentCount++;
            } else if (studentRecord.status === "absent") {
              absentCount++;
            }
          }
        });

        const totalSessions = presentCount + absentCount;
        const attendancePercentage = totalSessions > 0
          ? ((presentCount / totalSessions) * 100).toFixed(2)
          : 0;

        return {
          course: {
            _id: course._id,
            code: course.code,
            courseName: course.courseName,
          },
          totalSessions,
          presentCount,
          absentCount,
          attendancePercentage: parseFloat(attendancePercentage),
          recentSessions: sessions.slice(0, 5).map((session) => {
            const studentRecord = session.records.find(
              (record) => record.student.toString() === studentDetails._id.toString()
            );
            return {
              date: session.date,
              status: studentRecord ? studentRecord.status : "not-marked",
            };
          }),
        };
      })
    );

    const totalAllSessions = attendanceData.reduce((sum, data) => sum + data.totalSessions, 0);
    const totalPresentCount = attendanceData.reduce((sum, data) => sum + data.presentCount, 0);
    const overallAttendancePercentage = totalAllSessions > 0
      ? ((totalPresentCount / totalAllSessions) * 100).toFixed(2)
      : 0;

    /* Get today's schedule */
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const today = dayNames[new Date().getDay()];
    const todaySchedule = [];

    if (studentDetails.group) {
      const groupDetails = await Group.findById(studentDetails.group._id);
      const todayMap = groupDetails?.scheduleSlots?.get(today);

      if (todayMap) {
        for (const [lectureNumber, courseId] of todayMap.entries()) {
          const courseDoc = await Course.findById(courseId);
          if (courseDoc) {
            todaySchedule.push({
              lectureNumber: Number(lectureNumber),
              course: {
                _id: courseDoc._id,
                code: courseDoc.code,
                courseName: courseDoc.courseName,
              },
            });
          }
        }
      }

      todaySchedule.sort((a, b) => a.lectureNumber - b.lectureNumber);
    }

    res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        aadharNumber: user.aadharNumber,
        phoneNumber: user.phoneNumber,
        DOB: user.DOB,
        role: user.role,
        status: user.status,
      },
      studentDetails: {
        _id: studentDetails._id,
        enrollmentNumber: studentDetails.enrollmentNumber,
        department: studentDetails.department,
        program: studentDetails.program,
        semester: studentDetails.semester,
        academicYear: studentDetails.academicYear,
        fatherName: studentDetails.fatherName,
        fatherPhoneNumber: studentDetails.fatherPhoneNumber,
        collegeEmail: studentDetails.collegeEmail,
        group: studentDetails.group,
      },
      enrolledCourses,
      attendanceData,
      overallAttendance: {
        totalSessions: totalAllSessions,
        presentCount: totalPresentCount,
        absentCount: totalAllSessions - totalPresentCount,
        percentage: parseFloat(overallAttendancePercentage),
      },
      today,
      todaySchedule,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

/* ================= GET STUDENT COURSES ================= */

export const getStudentCourses = async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    if (!user || user.role !== "student") {
      return res.status(403).json({
        message: "Access denied. Not a student account.",
      });
    }

    const studentDetails = await Student.findOne({ user: user._id })
      .populate({
        path: "group",
        select: "courseIds",
        populate: {
          path: "courseIds",
          select: "code courseName department semester branch credit",
          populate: {
            path: "department",
            select: "name code"
          }
        }
      });

    if (!studentDetails) {
      return res.status(404).json({
        message: "Student profile not found",
      });
    }

    /* Get courses from group or enrollment */
    let courses = [];
    
    if (studentDetails.group && studentDetails.group.courseIds) {
      courses = studentDetails.group.courseIds;
    }
    
    if (courses.length === 0) {
      const enrollments = await Enrollment.find({ 
        student: studentDetails._id,
        status: "active"
      }).populate({
        path: "course",
        populate: {
          path: "department",
          select: "name code"
        }
      });
      courses = enrollments.map(enrollment => enrollment.course);
    }

    res.json({
      message: "Courses fetched successfully",
      count: courses.length,
      courses,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

/* ================= GET STUDENT ATTENDANCE SUMMARY ================= */

export const getStudentAttendanceSummary = async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    if (!user || user.role !== "student") {
      return res.status(403).json({
        message: "Access denied. Not a student account.",
      });
    }

    const studentDetails = await Student.findOne({ user: user._id })
      .populate({
        path: "group",
        select: "name courseIds",
        populate: {
          path: "courseIds",
          select: "code courseName"
        }
      });

    if (!studentDetails) {
      return res.status(404).json({
        message: "Student profile not found",
      });
    }

    /* Get courses from group or enrollment */
    let courses = [];
    
    if (studentDetails.group && studentDetails.group.courseIds) {
      courses = studentDetails.group.courseIds;
    }
    
    if (courses.length === 0) {
      const enrollments = await Enrollment.find({ 
        student: studentDetails._id,
        status: "active"
      }).populate("course", "code courseName");
      courses = enrollments.map(enrollment => enrollment.course);
    }

    const attendanceData = await Promise.all(
      courses.map(async (course) => {
        const courseId = course._id;
        
        const sessions = await AttendanceSession.find({
          group: studentDetails.group?._id,
          course: courseId,
        }).sort({ date: -1 });

        let presentCount = 0;
        let absentCount = 0;

        const sessionDetails = sessions.map((session) => {
          const studentRecord = session.records.find(
            (record) => record.student.toString() === studentDetails._id.toString()
          );

          if (studentRecord) {
            if (studentRecord.status === "present") {
              presentCount++;
            } else if (studentRecord.status === "absent") {
              absentCount++;
            }
          }

          return {
            _id: session._id,
            date: session.date,
            status: studentRecord ? studentRecord.status : "not-marked",
          };
        });

        const totalSessions = presentCount + absentCount;
        const attendancePercentage = totalSessions > 0
          ? ((presentCount / totalSessions) * 100).toFixed(2)
          : 0;

        return {
          course,
          totalSessions,
          presentCount,
          absentCount,
          attendancePercentage: parseFloat(attendancePercentage),
          sessions: sessionDetails,
        };
      })
    );

    res.json({
      message: "Attendance summary fetched successfully",
      group: studentDetails.group,
      attendanceData,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};
